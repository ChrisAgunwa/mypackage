# mypackage

This library is just an example of how to create and publish python package


# How to install

...